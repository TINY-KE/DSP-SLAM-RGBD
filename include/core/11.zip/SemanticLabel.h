
#ifndef ELLIPSOIDSLAM_SEMANTICLABEL_H
#define ELLIPSOIDSLAM_SEMANTICLABEL_H

const char* GetLabelText_Optimizer(int id);
bool CheckLabelOnGround(int label);

#endif //ELLIPSOIDSLAM_SEMANTICLABEL_H
